#ifndef __CONFIGGENERAL_H__
#define __CONFIGGENERAL_H__

#define MASTER 0x01
#define ETANG 0x02
#define TURBINE 0x03


#endif // __CONFIGGENERAL_H__