#include <Adafruit_SSD1306.h>
//#include "configuration.h"

#if !defined(__Ecran_)
#define __Ecran_

#if defined (ARDUINO_HELTEC_WIFI_LORA_32_V3) && defined (INTEGRATED_OLED)

    #pragma message "V3 oled"
    #undef RST_OLED
    #define RST_OLED 21
#elif defined (ARDUINO_HELTEC_WIFI_LORA_32_V3)
    #undef RST_OLED
    #define RST_OLED -1

#elif defined(ARDUINO_HELTEC_WIFI_LORA_32_V2)
    #pragma message "V2 oled"
#else
  #undef RST_OLED
  #define RST_OLED -1

#endif 

enum EcranState{
    EcranState_None,
    EcranState_IDLE,
    EcranState_Sleep
};

class Ecran
{
private:
    TwoWire* _iic;
    Adafruit_SSD1306* _display;
    EcranState _state = EcranState_None;
    unsigned long _millis = 0;
public:
    Ecran(TwoWire* iic = &Wire);
    ~Ecran();

    bool begin();
    EcranState getState();
    void loop();
    Adafruit_SSD1306* getDisplay();
    void setSleep();
    void wakeUp();
};





#endif // __Ecran_
